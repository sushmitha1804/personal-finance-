# CampusCare — College Complaint Management System

A full-stack Node.js project for students to submit campus complaints and for administrators to review, respond to, and update complaint status.

## Features

### Student
- Create an account with name, email, department and password.
- Sign in and sign out.
- Passwords are hashed using `bcryptjs`.
- Submit complaints with category, priority, location and description.
- Get a unique complaint reference ID.
- View only their own complaints.
- Filter/search complaint history and read administrator responses.

### Administrator
- Separate administrator role and dashboard.
- View all student complaints and submitter email addresses.
- Review a complaint and change its status.
- Add a response visible to the student.
- Dashboard counts for total, awaiting review, active, resolved and registered students.

### Technical
- Node.js + Express REST API.
- Session-based authentication.
- JSON file persistence, so no database installation is required.
- Responsive frontend.

## Requirements
- Node.js 18 or later
- npm

## Run on Windows

1. Extract `college-complaint-management-system.zip`.
2. Open Command Prompt in the extracted folder. For example:

   ```bat
   cd /d "C:\Users\USER\Desktop\college-complaint-management-system"
   ```

3. Install dependencies:

   ```bat
   npm install
   ```

4. Start the application:

   ```bat
   npm start
   ```

5. Open `http://localhost:3000` in your browser.

## Default administrator login

- **Email:** `admin@college.edu`
- **Password:** `Admin@123`

The administrator is created automatically the first time the server starts. If you change `ADMIN_EMAIL` or `ADMIN_PASSWORD` environment variables, the server creates an administrator using those values if that email does not already exist.

## Student login

Use **Create account** on the opening page to register a student account with a unique email address. If the email is already registered, sign in with that account instead. Each complaint is automatically associated with the currently signed-in student's name and email; students cannot submit complaints as another user.

## Data storage

The app stores users in `data/users.json` and complaints in `data/complaints.json`. Keep these files if you want to preserve project data. Back them up regularly.

## Important production notes

This is a runnable academic/demo project. Before deploying it publicly, set a strong `SESSION_SECRET`, use HTTPS, configure a persistent session store, add rate limiting and CSRF protections, and replace JSON-file storage with a database such as PostgreSQL or MongoDB. The default administrator password should be changed for any real deployment.
